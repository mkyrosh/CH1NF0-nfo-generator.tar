#!/bin/bash
# ═══════════════════════════════════════════════════════
#  CH1NF0 — Build script
#  Compile en exécutable pour Windows, Linux ou macOS
# ═══════════════════════════════════════════════════════

set -e

echo "╔══════════════════════════════════════╗"
echo "║  CH1NF0 Builder                      ║"
echo "╚══════════════════════════════════════╝"
echo ""

# Vérifier Python
if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 non trouvé. Installez Python 3.8+"
    exit 1
fi

echo "📦 Installation des dépendances..."
pip install --break-system-packages -r requirements.txt 2>/dev/null || pip install -r requirements.txt

echo ""
echo "🔨 Compilation de l'exécutable..."

# Detect OS
OS=$(uname -s)
case "$OS" in
    Linux*)     PLATFORM="linux";;
    Darwin*)    PLATFORM="macos";;
    MINGW*|MSYS*|CYGWIN*) PLATFORM="windows";;
    *)          PLATFORM="unknown";;
esac

echo "  Plateforme détectée : $PLATFORM"

pyinstaller \
    --onefile \
    --windowed \
    --name "CH1NF0" \
    --clean \
    nfo_generator.py

echo ""
echo "✅ Build terminé !"
echo "   Exécutable : dist/CH1NF0"
echo ""
echo "📋 Prérequis sur la machine cible :"
echo "   • mediainfo (apt install mediainfo / brew install mediainfo)"
echo "   • ffmpeg    (apt install ffmpeg / brew install ffmpeg)"
echo "     ffmpeg est optionnel mais nécessaire pour calculer les bitrates"
echo "     quand ils ne sont pas dans les headers du fichier."
