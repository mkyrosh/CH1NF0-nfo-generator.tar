#!/usr/bin/env python3
"""
╔═══════════════════════════════════════════════════════════╗
║   CH1NF0 — NFO Generator for Private Trackers            ║
║   Cross-platform (Windows / Linux / macOS)               ║
║   Drag & drop or browse to generate complete NFO files   ║
╚═══════════════════════════════════════════════════════════╝
"""

import os
import sys
import json
import subprocess
import re
import math
import threading
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, scrolledtext
from pathlib import Path
from datetime import datetime

# Optional imports
try:
    from pymediainfo import MediaInfo
    HAS_PYMEDIAINFO = True
except ImportError:
    HAS_PYMEDIAINFO = False

try:
    import requests
    HAS_REQUESTS = True
except ImportError:
    HAS_REQUESTS = False

try:
    import torf
    HAS_TORF = True
except ImportError:
    HAS_TORF = False


# ═══════════════════════════════════════════════════════════════════
#  CONSTANTS
# ═══════════════════════════════════════════════════════════════════

APP_NAME = "CH1NF0"
APP_VERSION = "0.1"
APP_AUTHOR = "Corridor"

VIDEO_EXTENSIONS = {
    '.mkv', '.mp4', '.avi', '.m4v', '.ts', '.wmv', '.flv', '.mov', '.mpg', '.mpeg'
}

TMDB_API_URL = "https://api.themoviedb.org/3"

BANNER = r"""╔═══════════════════════════════════════════════════════╗
║                                                       ║
║   ██████╗██╗  ██╗ ██╗ ██╗███╗   ██╗███████╗ ██████╗   ║
║  ██╔════╝██║  ██║███║███║████╗  ██║██╔════╝██╔═══██╗  ║
║  ██║     ███████║╚██║╚██║██╔██╗ ██║█████╗  ██║   ██║. ║
║  ██║     ╚════██║ ██║ ██║██║╚██╗██║██╔══╝  ██║   ██║. ║
║  ╚██████╗     ██║ ██║ ██║██║ ╚████║██║     ╚██████╔╝. ║
║   ╚═════╝     ╚═╝ ╚═╝ ╚═╝╚═╝  ╚═══╝╚═╝      ╚═════╝   ║
║                                                       ║
║                -= MediaInfo vers NFO =-               ║
║                     par {author}{pad}║
║                                                       ║
║          Hors ligne  •   Rapide  •   Précis           ║
║                                                       ║
╚═══════════════════════════════════════════════════════╝""".format(
    author=APP_AUTHOR, pad=" " * (24 - len(APP_AUTHOR))
)


# ═══════════════════════════════════════════════════════════════════
#  MEDIA ANALYSIS ENGINE
# ═══════════════════════════════════════════════════════════════════

class MediaAnalyzer:
    """Extracts technical information from media files."""

    def __init__(self, log_callback=None):
        self.log = log_callback or print
        self.ffprobe_path = self._find_ffprobe()

    def _find_ffprobe(self):
        """Locate ffprobe binary."""
        names = ['ffprobe', 'ffprobe.exe']
        for name in names:
            try:
                result = subprocess.run(
                    [name, '-version'],
                    capture_output=True, timeout=5
                )
                if result.returncode == 0:
                    return name
            except (FileNotFoundError, subprocess.TimeoutExpired):
                continue
        return None

    def analyze_file(self, filepath):
        """Analyze a single media file and return structured data."""
        filepath = str(filepath)
        self.log(f"  Analyse de : {os.path.basename(filepath)}")
        info = {
            'filename': os.path.basename(filepath),
            'filepath': filepath,
            'general': {},
            'video': {},
            'audio': [],
            'subtitles': [],
            'chapters': [],
        }

        if HAS_PYMEDIAINFO:
            self._analyze_pymediainfo(filepath, info)
        elif self.ffprobe_path:
            self._analyze_ffprobe_full(filepath, info)
        else:
            self.log("  ⚠ Ni pymediainfo ni ffprobe disponible !")
            return info

        # If bitrates are missing, calculate them
        if not info['video'].get('bit_rate') and self.ffprobe_path:
            self._calculate_bitrates(filepath, info)

        return info

    def _analyze_pymediainfo(self, filepath, info):
        """Analyze using pymediainfo."""
        try:
            mi = MediaInfo.parse(filepath, full=True)
        except Exception as e:
            self.log(f"  ⚠ Erreur pymediainfo: {e}")
            if self.ffprobe_path:
                self._analyze_ffprobe_full(filepath, info)
            return

        for track in mi.tracks:
            if track.track_type == 'General':
                info['general'] = {
                    'format': track.format or '',
                    'format_version': track.format_version or '',
                    'file_size': track.file_size or 0,
                    'file_size_str': self._format_size(track.file_size or 0),
                    'duration': track.duration or 0,
                    'duration_str': self._format_duration(track.duration or 0),
                    'overall_bit_rate': track.overall_bit_rate or 0,
                    'overall_bit_rate_str': self._format_bitrate(track.overall_bit_rate or 0),
                    'frame_rate': track.frame_rate or '',
                    'encoded_date': track.encoded_date or '',
                    'writing_application': track.writing_application or '',
                    'writing_library': track.writing_library or '',
                    'unique_id': track.unique_id or '',
                    'title': track.title or '',
                }

            elif track.track_type == 'Video':
                encoding_settings = track.encoding_settings or ''
                info['video'] = {
                    'format': track.format or '',
                    'format_info': track.format_info or '',
                    'format_profile': track.format_profile or '',
                    'format_settings': track.format_settings or '',
                    'codec_id': track.codec_id or '',
                    'duration': track.duration or 0,
                    'duration_str': self._format_duration(track.duration or 0),
                    'bit_rate': track.bit_rate or 0,
                    'bit_rate_str': self._format_bitrate(track.bit_rate or 0),
                    'bit_rate_mode': track.bit_rate_mode or '',
                    'width': track.width or 0,
                    'height': track.height or 0,
                    'display_aspect_ratio': track.display_aspect_ratio or '',
                    'frame_rate': track.frame_rate or '',
                    'frame_rate_mode': track.frame_rate_mode or '',
                    'color_space': track.color_space or '',
                    'chroma_subsampling': track.chroma_subsampling or '',
                    'bit_depth': track.bit_depth or '',
                    'scan_type': track.scan_type or '',
                    'writing_library': track.writing_library or '',
                    'encoding_settings': encoding_settings,
                    'color_range': track.color_range or '',
                    'color_primaries': track.color_primaries or '',
                    'transfer_characteristics': track.transfer_characteristics or '',
                    'matrix_coefficients': track.matrix_coefficients or '',
                    'stream_size': track.stream_size or 0,
                    'bits_pixel_frame': track.bits__pixel_frame_ if hasattr(track, 'bits__pixel_frame_') else '',
                }
                # Parse x264/x265 settings
                info['video']['x264_params'] = self._parse_encoding_settings(encoding_settings)

            elif track.track_type == 'Audio':
                info['audio'].append({
                    'format': track.format or '',
                    'format_info': track.format_info or '',
                    'commercial_name': track.commercial_name or '',
                    'codec_id': track.codec_id or '',
                    'duration': track.duration or 0,
                    'bit_rate': track.bit_rate or 0,
                    'bit_rate_str': self._format_bitrate(track.bit_rate or 0),
                    'bit_rate_mode': track.bit_rate_mode or '',
                    'channels': track.channel_s or 0,
                    'channel_layout': track.channel_layout or '',
                    'sampling_rate': track.sampling_rate or '',
                    'bit_depth': track.bit_depth or '',
                    'compression_mode': track.compression_mode or '',
                    'language': track.language or '',
                    'title': track.title or '',
                    'stream_size': track.stream_size or 0,
                    'delay': track.delay_relative_to_video or '',
                })

            elif track.track_type == 'Text':
                info['subtitles'].append({
                    'format': track.format or '',
                    'codec_id': track.codec_id or '',
                    'language': track.language or '',
                    'title': track.title or '',
                    'forced': track.forced or '',
                    'default': track.default or '',
                })

            elif track.track_type == 'Menu':
                # Extract chapters from menu track
                pass

        # Try to get chapters via other attributes
        try:
            mi_text = MediaInfo.parse(filepath, text=True)
            info['chapters'] = self._extract_chapters_from_text(mi_text)
        except Exception:
            pass

    def _extract_chapters_from_text(self, text):
        """Extract chapters from MediaInfo text output."""
        chapters = []
        in_menu = False
        for line in text.split('\n'):
            if line.strip().lower().startswith('menu'):
                in_menu = True
                continue
            if in_menu and ':' in line:
                match = re.match(r'\s*(\d{2}:\d{2}:\d{2}[\.\d]*)\s*:\s*(.*)', line)
                if match:
                    chapters.append({
                        'time': match.group(1),
                        'title': match.group(2).strip(),
                    })
            elif in_menu and line.strip() == '':
                if chapters:
                    break
        return chapters

    def _analyze_ffprobe_full(self, filepath, info):
        """Full analysis using ffprobe as fallback."""
        try:
            result = subprocess.run(
                [self.ffprobe_path, '-v', 'quiet', '-print_format', 'json',
                 '-show_format', '-show_streams', '-show_chapters', filepath],
                capture_output=True, text=True, timeout=60
            )
            data = json.loads(result.stdout)
        except Exception as e:
            self.log(f"  ⚠ Erreur ffprobe: {e}")
            return

        fmt = data.get('format', {})
        info['general'] = {
            'format': fmt.get('format_long_name', ''),
            'format_version': '',
            'file_size': int(fmt.get('size', 0)),
            'file_size_str': self._format_size(int(fmt.get('size', 0))),
            'duration': float(fmt.get('duration', 0)) * 1000,
            'duration_str': self._format_duration(float(fmt.get('duration', 0)) * 1000),
            'overall_bit_rate': int(fmt.get('bit_rate', 0)),
            'overall_bit_rate_str': self._format_bitrate(int(fmt.get('bit_rate', 0))),
            'frame_rate': '',
            'encoded_date': fmt.get('tags', {}).get('creation_time', ''),
            'writing_application': fmt.get('tags', {}).get('encoder', ''),
            'writing_library': '',
            'unique_id': '',
            'title': fmt.get('tags', {}).get('title', ''),
        }

        for stream in data.get('streams', []):
            if stream.get('codec_type') == 'video':
                info['video'] = {
                    'format': stream.get('codec_long_name', ''),
                    'format_info': '',
                    'format_profile': stream.get('profile', ''),
                    'format_settings': '',
                    'codec_id': stream.get('codec_tag_string', ''),
                    'duration': float(stream.get('duration', 0)) * 1000 if stream.get('duration') else 0,
                    'duration_str': self._format_duration(float(stream.get('duration', 0)) * 1000) if stream.get('duration') else '',
                    'bit_rate': int(stream.get('bit_rate', 0)) if stream.get('bit_rate') else 0,
                    'bit_rate_str': self._format_bitrate(int(stream.get('bit_rate', 0))) if stream.get('bit_rate') else '',
                    'bit_rate_mode': '',
                    'width': stream.get('width', 0),
                    'height': stream.get('height', 0),
                    'display_aspect_ratio': stream.get('display_aspect_ratio', ''),
                    'frame_rate': stream.get('r_frame_rate', ''),
                    'frame_rate_mode': '',
                    'color_space': stream.get('pix_fmt', ''),
                    'chroma_subsampling': '',
                    'bit_depth': stream.get('bits_per_raw_sample', ''),
                    'scan_type': '',
                    'writing_library': '',
                    'encoding_settings': '',
                    'color_range': stream.get('color_range', ''),
                    'color_primaries': stream.get('color_primaries', ''),
                    'transfer_characteristics': stream.get('color_transfer', ''),
                    'matrix_coefficients': stream.get('color_space', ''),
                    'stream_size': 0,
                    'bits_pixel_frame': '',
                    'x264_params': {},
                }

            elif stream.get('codec_type') == 'audio':
                info['audio'].append({
                    'format': stream.get('codec_long_name', ''),
                    'format_info': '',
                    'commercial_name': '',
                    'codec_id': stream.get('codec_tag_string', ''),
                    'duration': float(stream.get('duration', 0)) * 1000 if stream.get('duration') else 0,
                    'bit_rate': int(stream.get('bit_rate', 0)) if stream.get('bit_rate') else 0,
                    'bit_rate_str': self._format_bitrate(int(stream.get('bit_rate', 0))) if stream.get('bit_rate') else '',
                    'bit_rate_mode': '',
                    'channels': stream.get('channels', 0),
                    'channel_layout': stream.get('channel_layout', ''),
                    'sampling_rate': stream.get('sample_rate', ''),
                    'bit_depth': stream.get('bits_per_sample', ''),
                    'compression_mode': 'Lossy',
                    'language': stream.get('tags', {}).get('language', ''),
                    'title': stream.get('tags', {}).get('title', ''),
                    'stream_size': 0,
                    'delay': '',
                })

            elif stream.get('codec_type') == 'subtitle':
                info['subtitles'].append({
                    'format': stream.get('codec_long_name', ''),
                    'codec_id': stream.get('codec_tag_string', ''),
                    'language': stream.get('tags', {}).get('language', ''),
                    'title': stream.get('tags', {}).get('title', ''),
                    'forced': '',
                    'default': '',
                })

        for ch in data.get('chapters', []):
            start = float(ch.get('start_time', 0))
            h = int(start // 3600)
            m = int((start % 3600) // 60)
            s = start % 60
            info['chapters'].append({
                'time': f"{h:02d}:{m:02d}:{s:06.3f}",
                'title': ch.get('tags', {}).get('title', f"Chapter {len(info['chapters'])+1}"),
            })

    def _calculate_bitrates(self, filepath, info):
        """Calculate bitrates by scanning all packets with ffprobe."""
        if not self.ffprobe_path:
            return

        self.log(f"  ⏳ Calcul des bitrates (scan des paquets)...")

        duration_ms = info['general'].get('duration', 0)
        if not duration_ms:
            return
        duration_s = duration_ms / 1000

        # Video stream size
        try:
            result = subprocess.run(
                [self.ffprobe_path, '-v', 'quiet', '-select_streams', 'v:0',
                 '-show_entries', 'packet=size', '-of', 'csv=p=0', filepath],
                capture_output=True, text=True, timeout=300
            )
            video_bytes = sum(int(line.strip()) for line in result.stdout.strip().split('\n') if line.strip())
            video_bitrate = int((video_bytes * 8) / duration_s)
            info['video']['bit_rate'] = video_bitrate
            info['video']['bit_rate_str'] = self._format_bitrate(video_bitrate)
            info['video']['bit_rate_mode'] = 'VBR'
            info['video']['stream_size'] = video_bytes
            self.log(f"    Vidéo : {self._format_bitrate(video_bitrate)}")
        except Exception as e:
            self.log(f"    ⚠ Erreur calcul bitrate vidéo: {e}")

        # Audio stream sizes
        for i, audio in enumerate(info['audio']):
            if audio.get('bit_rate'):
                continue
            try:
                result = subprocess.run(
                    [self.ffprobe_path, '-v', 'quiet', '-select_streams', f'a:{i}',
                     '-show_entries', 'packet=size', '-of', 'csv=p=0', filepath],
                    capture_output=True, text=True, timeout=300
                )
                audio_bytes = sum(int(line.strip()) for line in result.stdout.strip().split('\n') if line.strip())
                audio_bitrate = int((audio_bytes * 8) / duration_s)
                info['audio'][i]['bit_rate'] = audio_bitrate
                info['audio'][i]['bit_rate_str'] = self._format_bitrate(audio_bitrate)
                info['audio'][i]['stream_size'] = audio_bytes
                self.log(f"    Audio #{i+1} : {self._format_bitrate(audio_bitrate)}")
            except Exception as e:
                self.log(f"    ⚠ Erreur calcul bitrate audio #{i+1}: {e}")

    def _parse_encoding_settings(self, settings_str):
        """Parse x264/x265 encoding settings string."""
        params = {}
        if not settings_str:
            return params
        for part in settings_str.split(' / '):
            if '=' in part:
                key, val = part.split('=', 1)
                params[key.strip()] = val.strip()
        return params

    @staticmethod
    def _format_size(size_bytes):
        if not size_bytes:
            return 'N/A'
        size_bytes = int(size_bytes)
        if size_bytes >= 1073741824:
            return f"{size_bytes / 1073741824:.2f} GiB"
        elif size_bytes >= 1048576:
            return f"{size_bytes / 1048576:.0f} MiB"
        elif size_bytes >= 1024:
            return f"{size_bytes / 1024:.0f} KiB"
        return f"{size_bytes} B"

    @staticmethod
    def _format_duration(ms):
        if not ms:
            return 'N/A'
        ms = float(ms)
        total_seconds = ms / 1000
        hours = int(total_seconds // 3600)
        minutes = int((total_seconds % 3600) // 60)
        if hours > 0:
            return f"{hours} h {minutes:02d} min"
        return f"{minutes} min"

    @staticmethod
    def _format_bitrate(bps):
        if not bps:
            return 'N/A'
        bps = int(bps)
        if bps >= 1000000:
            return f"{bps / 1000000:.1f} Mb/s"
        elif bps >= 1000:
            return f"{bps / 1000:.0f} kb/s"
        return f"{bps} b/s"


# ═══════════════════════════════════════════════════════════════════
#  TMDB METADATA FETCHER
# ═══════════════════════════════════════════════════════════════════

class TMDBFetcher:
    """Fetch movie/series metadata from TMDB API."""

    def __init__(self, api_key=None, log_callback=None):
        self.api_key = api_key or ""
        self.log = log_callback or print

    def search(self, query, media_type='multi'):
        """Search TMDB for a movie or TV show."""
        if not self.api_key or not HAS_REQUESTS:
            return None

        clean_query = self._clean_filename(query)
        self.log(f"  🔍 Recherche TMDB : {clean_query}")

        try:
            url = f"{TMDB_API_URL}/search/{media_type}"
            params = {
                'api_key': self.api_key,
                'query': clean_query,
                'language': 'fr-FR',
            }
            resp = requests.get(url, params=params, timeout=10)
            resp.raise_for_status()
            data = resp.json()

            if data.get('results'):
                result = data['results'][0]
                return self._get_details(result)
        except Exception as e:
            self.log(f"  ⚠ Erreur TMDB: {e}")
        return None

    def _get_details(self, result):
        """Get full details for a TMDB result."""
        media_type = result.get('media_type', 'movie')
        tmdb_id = result.get('id')

        if media_type == 'tv':
            endpoint = f"{TMDB_API_URL}/tv/{tmdb_id}"
        else:
            endpoint = f"{TMDB_API_URL}/movie/{tmdb_id}"

        try:
            params = {
                'api_key': self.api_key,
                'language': 'fr-FR',
                'append_to_response': 'credits,external_ids',
            }
            resp = requests.get(endpoint, params=params, timeout=10)
            resp.raise_for_status()
            data = resp.json()

            # Format release date nicely
            raw_date = data.get('release_date') or data.get('first_air_date', '')
            formatted_date = ''
            if raw_date:
                try:
                    from datetime import datetime as dt
                    d = dt.strptime(raw_date, '%Y-%m-%d')
                    jours = ['lundi','mardi','mercredi','jeudi','vendredi','samedi','dimanche']
                    mois = ['janvier','février','mars','avril','mai','juin',
                            'juillet','août','septembre','octobre','novembre','décembre']
                    formatted_date = f"{jours[d.weekday()]} {d.day} {mois[d.month-1]} {d.year}"
                except Exception:
                    formatted_date = raw_date

            # Format runtime
            runtime_raw = data.get('runtime') or 0
            runtime_str = ''
            if runtime_raw:
                rh = int(runtime_raw) // 60
                rm = int(runtime_raw) % 60
                runtime_str = f"{rh}h{rm:02d}min" if rh else f"{rm}min"

            # IMDB ID
            imdb_id = ''
            ext_ids = data.get('external_ids', {})
            if ext_ids:
                imdb_id = ext_ids.get('imdb_id', '')
            if not imdb_id:
                imdb_id = data.get('imdb_id', '')

            # Poster
            poster_path = data.get('poster_path', '')
            poster_url = f"https://image.tmdb.org/t/p/w500{poster_path}" if poster_path else ''

            info = {
                'title': data.get('title') or data.get('name', ''),
                'original_title': data.get('original_title') or data.get('original_name', ''),
                'year': raw_date[:4] if raw_date else '',
                'release_date': formatted_date,
                'overview': data.get('overview', ''),
                'genres': ', '.join(g['name'] for g in data.get('genres', [])),
                'rating': data.get('vote_average', ''),
                'runtime': runtime_raw,
                'runtime_str': runtime_str,
                'type': 'Série TV' if media_type == 'tv' else 'Film',
                'countries': ', '.join(
                    c.get('name', c.get('iso_3166_1', ''))
                    for c in data.get('production_countries', data.get('origin_country', []))
                ) if data.get('production_countries') else '',
                'production': ', '.join(
                    c['name'] for c in data.get('production_companies', [])[:5]
                ),
                'cast': [],
                'director': '',
                'seasons': data.get('number_of_seasons', ''),
                'episodes': data.get('number_of_episodes', ''),
                'imdb_id': imdb_id,
                'poster_url': poster_url,
            }

            # Credits
            credits = data.get('credits', {})
            for person in credits.get('cast', [])[:12]:
                info['cast'].append({
                    'name': person.get('name', ''),
                    'character': person.get('character', ''),
                })

            directors = [
                p['name'] for p in credits.get('crew', [])
                if p.get('job') in ('Director', 'Réalisateur')
            ]
            info['director'] = ', '.join(directors) if directors else ''

            # For TV, also get created_by
            if media_type == 'tv' and not info['director']:
                creators = [c['name'] for c in data.get('created_by', [])]
                info['director'] = ', '.join(creators) if creators else ''

            self.log(f"  ✓ Trouvé : {info['title']} ({info['year']})")
            return info

        except Exception as e:
            self.log(f"  ⚠ Erreur détails TMDB: {e}")
            return None

    @staticmethod
    def _clean_filename(filename):
        """Extract a searchable title from a filename."""
        name = filename
        # Remove extension
        name = re.sub(r'\.[a-zA-Z0-9]{2,4}$', '', name)
        # Remove common tags
        patterns = [
            r'[\.\-_](FRENCH|VOSTFR|VF|VO|MULTI|MULTi)',
            r'[\.\-_](DVDRip|BDRip|BRRip|HDRip|WEBRip|WEB[\.\-]?DL|HDLight|BluRay|REMUX)',
            r'[\.\-_](x264|x265|h264|h265|HEVC|AVC|XviD)',
            r'[\.\-_](720p|1080p|1080i|2160p|4K|480p|576p)',
            r'[\.\-_](AC3|DTS|AAC|FLAC|TrueHD|Atmos|DD[P5])',
            r'[\.\-_](part\d+)',
            r'-[a-zA-Z0-9]+$',  # release group
            r'\b(19|20)\d{2}\b',  # year
        ]
        for pattern in patterns:
            name = re.sub(pattern, ' ', name, flags=re.IGNORECASE)
        # Replace dots/underscores with spaces
        name = re.sub(r'[\.\-_]+', ' ', name)
        name = re.sub(r'\s+', ' ', name).strip()
        return name


# ═══════════════════════════════════════════════════════════════════
#  NFO FORMATTER
# ═══════════════════════════════════════════════════════════════════

class NFOFormatter:
    """Format analyzed data into NFO text."""

    @staticmethod
    def generate(files_info, tmdb_info=None, release_name=''):
        """Generate complete NFO from analyzed files."""
        lines = []
        lines.append(BANNER)
        lines.append('')
        lines.append('')

        # ── TMDB info section ──
        if tmdb_info:
            lines.append('═' * 79)
            lines.append('                       INFORMATIONS SUR L\'OEUVRE')
            lines.append('═' * 79)
            lines.append('')

            fields = [
                ('Titre', tmdb_info.get('title', '')),
                ('Titre original', tmdb_info.get('original_title', '')),
                ('Type', tmdb_info.get('type', '')),
                ('Année', tmdb_info.get('year', '')),
                ('Pays', tmdb_info.get('countries', '')),
                ('Genre', tmdb_info.get('genres', '')),
            ]

            if tmdb_info.get('director'):
                label = 'Réalisateur' if tmdb_info.get('type') != 'Série TV' else 'Créateur'
                fields.append((label, tmdb_info['director']))

            if tmdb_info.get('seasons'):
                fields.append(('Saisons', str(tmdb_info['seasons'])))
            if tmdb_info.get('episodes'):
                fields.append(('Épisodes', str(tmdb_info['episodes'])))
            if tmdb_info.get('runtime'):
                fields.append(('Durée', f"{tmdb_info['runtime']} min"))
            if tmdb_info.get('production'):
                fields.append(('Production', tmdb_info['production']))
            if tmdb_info.get('rating'):
                fields.append(('Note TMDB', f"{tmdb_info['rating']}/10"))

            for label, value in fields:
                if value and value != tmdb_info.get('title', '') or label == 'Titre':
                    lines.append(f"  {label:<20} : {value}")

            # Cast
            if tmdb_info.get('cast'):
                lines.append('')
                lines.append(f"  {'Casting principal':<20} :")
                max_name = max(len(c['name']) for c in tmdb_info['cast'])
                for actor in tmdb_info['cast']:
                    dots = '.' * (max_name - len(actor['name']) + 3)
                    lines.append(f"    {actor['name']} {dots} {actor['character']}")

            # Synopsis
            if tmdb_info.get('overview'):
                lines.append('')
                synopsis = tmdb_info['overview']
                # Word wrap at 60 chars
                words = synopsis.split()
                current_line = "  Synopsis           : "
                first = True
                for word in words:
                    if len(current_line) + len(word) + 1 > 75:
                        lines.append(current_line)
                        current_line = "                       " + word
                    else:
                        if first:
                            current_line += word
                            first = False
                        else:
                            current_line += ' ' + word
                if current_line.strip():
                    lines.append(current_line)

            lines.append('')
            lines.append('')

        # ── Release info section ──
        lines.append('═' * 79)
        lines.append('                        INFORMATIONS SUR LE RELEASE')
        lines.append('═' * 79)
        lines.append('')

        if release_name:
            lines.append(f"  Release            : {release_name}")

        # Calculate totals
        total_size = sum(f['general'].get('file_size', 0) for f in files_info)
        total_duration = sum(f['general'].get('duration', 0) for f in files_info)

        lines.append(f"  Conteneur          : {files_info[0]['general'].get('format', 'N/A')}")

        if files_info[0]['video'].get('writing_library'):
            lines.append(f"  Codec vidéo        : {files_info[0]['video'].get('writing_library', '')}")
        elif files_info[0]['video'].get('format'):
            lines.append(f"  Codec vidéo        : {files_info[0]['video']['format']}")

        if files_info[0]['audio']:
            audio_formats = []
            for a in files_info[0]['audio']:
                fmt = a.get('format', '')
                if a.get('commercial_name') and a['commercial_name'] != fmt:
                    fmt += f" ({a['commercial_name']})"
                audio_formats.append(fmt)
            lines.append(f"  Codec audio        : {' / '.join(audio_formats)}")

        # Languages
        languages = set()
        for f in files_info:
            for a in f['audio']:
                if a.get('language'):
                    languages.add(a['language'].title())
        if languages:
            lines.append(f"  Langue audio       : {', '.join(sorted(languages))}")

        # Subtitles
        sub_langs = set()
        for f in files_info:
            for s in f['subtitles']:
                if s.get('language'):
                    sub_langs.add(s['language'].title())
        lines.append(f"  Sous-titres        : {', '.join(sorted(sub_langs)) if sub_langs else 'Aucun'}")

        lines.append(f"  Nombre de fichiers : {len(files_info)}")
        lines.append(f"  Taille totale      : {MediaAnalyzer._format_size(total_size)}")
        lines.append(f"  Durée totale       : {MediaAnalyzer._format_duration(total_duration)}")

        if files_info[0]['general'].get('writing_application'):
            lines.append(f"  Encodeur           : {files_info[0]['general']['writing_application']}")

        lines.append('')
        lines.append('')

        # ── Per-file sections ──
        for idx, finfo in enumerate(files_info):
            lines.append('═' * 79)
            if len(files_info) > 1:
                lines.append(f"  PART {idx+1} — {finfo['filename']}")
            else:
                lines.append(f"  {finfo['filename']}")
            lines.append('═' * 79)
            lines.append('')

            # General
            lines.append('  ┌' + '─' * 73 + '┐')
            lines.append('  │  GENERAL' + ' ' * 63 + '│')
            lines.append('  ├' + '─' * 73 + '┤')

            gen = finfo['general']
            gen_fields = []
            if gen.get('unique_id'):
                uid = gen['unique_id']
                if isinstance(uid, int):
                    uid = f"0x{uid:032X}"
                gen_fields.append(('Unique ID', str(uid)))
            gen_fields.append(('Format', f"{gen.get('format', '')} ({gen.get('format_version', '')})".rstrip(' ()')))
            gen_fields.append(('Taille', gen.get('file_size_str', 'N/A')))
            gen_fields.append(('Durée', gen.get('duration_str', 'N/A')))
            gen_fields.append(('Débit global', gen.get('overall_bit_rate_str', 'N/A')))

            # Video + Audio bitrates in general
            vid = finfo['video']
            if vid.get('bit_rate_str') and vid['bit_rate_str'] != 'N/A':
                mode = 'VBR - CRF' if vid.get('x264_params', {}).get('rc') == 'crf' else vid.get('bit_rate_mode', '')
                gen_fields.append(('Débit vidéo', f"{vid['bit_rate_str']} ({mode})" if mode else vid['bit_rate_str']))
            if finfo['audio']:
                for i, aud in enumerate(finfo['audio']):
                    if aud.get('bit_rate_str') and aud['bit_rate_str'] != 'N/A':
                        label = f"Débit audio{f' #{i+1}' if len(finfo['audio']) > 1 else ''}"
                        gen_fields.append((label, f"{aud['bit_rate_str']} ({aud.get('bit_rate_mode', 'VBR')})"))

            gen_fields.append(('Framerate', f"{gen.get('frame_rate', 'N/A')} FPS"))
            if gen.get('encoded_date'):
                gen_fields.append(('Date d\'encodage', gen['encoded_date']))
            if gen.get('writing_application'):
                gen_fields.append(('Application', gen['writing_application']))
            if gen.get('writing_library'):
                gen_fields.append(('Librairie', gen['writing_library']))

            for label, value in gen_fields:
                cell = f"  │  {label:<20} : {value}"
                cell += ' ' * max(0, 75 - len(cell)) + '│'
                lines.append(cell)
            lines.append('  └' + '─' * 73 + '┘')
            lines.append('')

            # Video
            if finfo['video']:
                lines.append('  ┌' + '─' * 73 + '┐')
                lines.append('  │  VIDEO' + ' ' * 65 + '│')
                lines.append('  ├' + '─' * 73 + '┤')

                vid = finfo['video']
                vid_fields = []

                codec_str = vid.get('format', '')
                if vid.get('writing_library'):
                    codec_str += f" ({vid['writing_library']})"
                vid_fields.append(('Codec', codec_str))

                if vid.get('format_profile'):
                    vid_fields.append(('Profil', vid['format_profile']))

                if vid.get('bit_rate_str') and vid['bit_rate_str'] != 'N/A':
                    x264p = vid.get('x264_params', {})
                    mode_info = ''
                    if x264p.get('rc') == 'crf' and x264p.get('crf'):
                        mode_info = f"VBR - CRF {x264p['crf']}"
                    elif vid.get('bit_rate_mode'):
                        mode_info = vid['bit_rate_mode']
                    bitrate_str = f"{vid['bit_rate_str']} ({mode_info})" if mode_info else vid['bit_rate_str']
                    vid_fields.append(('Débit', bitrate_str))

                vid_fields.append(('Résolution', f"{vid.get('width', '?')} x {vid.get('height', '?')} pixels"))
                if vid.get('display_aspect_ratio'):
                    vid_fields.append(('Ratio', vid['display_aspect_ratio']))
                vid_fields.append(('Framerate', f"{vid.get('frame_rate', 'N/A')} FPS ({vid.get('frame_rate_mode', '')})"))
                if vid.get('color_space') and vid.get('chroma_subsampling'):
                    vid_fields.append(('Espace couleur', f"{vid['color_space']} {vid['chroma_subsampling']}"))
                if vid.get('bit_depth'):
                    vid_fields.append(('Profondeur', f"{vid['bit_depth']} bits"))
                if vid.get('scan_type'):
                    vid_fields.append(('Scan', vid['scan_type']))
                if vid.get('color_primaries'):
                    vid_fields.append(('Couleur primaires', vid['color_primaries']))
                if vid.get('transfer_characteristics'):
                    vid_fields.append(('Transfert', vid['transfer_characteristics']))
                if vid.get('matrix_coefficients'):
                    vid_fields.append(('Matrice', vid['matrix_coefficients']))

                for label, value in vid_fields:
                    cell = f"  │  {label:<20} : {value}"
                    cell += ' ' * max(0, 75 - len(cell)) + '│'
                    lines.append(cell)

                # x264/x265 params
                x264p = vid.get('x264_params', {})
                if x264p:
                    lines.append('  │' + ' ' * 73 + '│')
                    cell = "  │  Paramètres x264     :"
                    cell += ' ' * max(0, 75 - len(cell)) + '│'
                    lines.append(cell)

                    param_fields = []
                    if x264p.get('rc') and x264p.get('crf'):
                        param_fields.append(('Mode', f"CRF {x264p['crf']}"))
                    elif x264p.get('rc'):
                        param_fields.append(('Mode', x264p['rc'].upper()))

                    # Estimate preset
                    preset = NFOFormatter._estimate_preset(x264p)
                    if preset:
                        param_fields.append(('Preset estimé', f"~{preset}"))

                    if x264p.get('cabac'):
                        param_fields.append(('CABAC', 'Oui' if x264p['cabac'] == '1' else 'Non'))
                    if x264p.get('ref'):
                        param_fields.append(('Ref frames', x264p['ref']))
                    if x264p.get('bframes'):
                        bf_detail = x264p['bframes']
                        if x264p.get('b_pyramid'):
                            bf_detail += f" (pyramid={x264p['b_pyramid']}, adapt={x264p.get('b_adapt', '?')})"
                        param_fields.append(('B-frames', bf_detail))
                    if x264p.get('deblock'):
                        param_fields.append(('Deblock', x264p['deblock']))
                    if x264p.get('me'):
                        me_str = x264p['me']
                        if x264p.get('me_range'):
                            me_str += f" (me_range={x264p['me_range']})"
                        param_fields.append(('Motion Estimation', me_str))
                    if x264p.get('subme'):
                        param_fields.append(('Subpixel ME', x264p['subme']))
                    if x264p.get('psy_rd'):
                        param_fields.append(('Psy-RD', x264p['psy_rd']))
                    if x264p.get('trellis'):
                        param_fields.append(('Trellis', x264p['trellis']))
                    if '8x8dct' in x264p:
                        param_fields.append(('8x8 DCT', 'Oui' if x264p['8x8dct'] == '1' else 'Non'))
                    if x264p.get('rc_lookahead'):
                        param_fields.append(('Lookahead', f"{x264p['rc_lookahead']} frames"))
                    if x264p.get('vbv_maxrate'):
                        param_fields.append(('VBV maxrate', f"{x264p['vbv_maxrate']} kb/s"))
                    if x264p.get('vbv_bufsize'):
                        param_fields.append(('VBV bufsize', f"{x264p['vbv_bufsize']} kb"))
                    if x264p.get('aq'):
                        parts = x264p['aq'].split(':')
                        if len(parts) == 2:
                            param_fields.append(('AQ', f"Mode {parts[0]}, force {parts[1]}"))

                    for label, value in param_fields:
                        cell = f"  │    {label:<18} : {value}"
                        cell += ' ' * max(0, 75 - len(cell)) + '│'
                        lines.append(cell)

                lines.append('  └' + '─' * 73 + '┘')
                lines.append('')

            # Audio tracks
            for aud_idx, aud in enumerate(finfo['audio']):
                lines.append('  ┌' + '─' * 73 + '┐')
                label = f"AUDIO" + (f" #{aud_idx+1}" if len(finfo['audio']) > 1 else "")
                lines.append(f"  │  {label}" + ' ' * (73 - len(label) - 3) + '│')
                lines.append('  ├' + '─' * 73 + '┤')

                aud_fields = []
                fmt = aud.get('format', '')
                if aud.get('format_info'):
                    fmt += f" ({aud['format_info']})"
                elif aud.get('commercial_name') and aud['commercial_name'] != aud.get('format'):
                    fmt += f" ({aud['commercial_name']})"
                aud_fields.append(('Format', fmt))

                if aud.get('bit_rate_str') and aud['bit_rate_str'] != 'N/A':
                    mode = aud.get('bit_rate_mode', 'VBR')
                    aud_fields.append(('Débit', f"{aud['bit_rate_str']} ({mode})"))

                ch = aud.get('channels', 0)
                ch_layout = aud.get('channel_layout', '')
                if ch:
                    ch_str = f"{ch} canal{'aux' if ch > 1 else ''}"
                    if ch_layout:
                        ch_str += f" ({ch_layout})"
                    if ch == 2:
                        ch_str = f"2.0 Stéréo ({ch_layout})" if ch_layout else "2.0 Stéréo"
                    elif ch == 6:
                        ch_str = f"5.1 ({ch_layout})" if ch_layout else "5.1"
                    elif ch == 8:
                        ch_str = f"7.1 ({ch_layout})" if ch_layout else "7.1"
                    aud_fields.append(('Canaux', ch_str))

                if aud.get('sampling_rate'):
                    sr = aud['sampling_rate']
                    if isinstance(sr, (int, float)):
                        sr = f"{float(sr)/1000:.1f} kHz"
                    elif not 'kHz' in str(sr):
                        sr = f"{sr} Hz"
                    aud_fields.append(('Échantillonnage', str(sr)))

                if aud.get('bit_depth'):
                    aud_fields.append(('Profondeur', f"{aud['bit_depth']} bits"))
                if aud.get('compression_mode'):
                    aud_fields.append(('Compression', aud['compression_mode']))
                if aud.get('language'):
                    aud_fields.append(('Langue', aud['language'].title()))
                if aud.get('title'):
                    aud_fields.append(('Titre', aud['title']))
                if aud.get('delay'):
                    aud_fields.append(('Délai / vidéo', f"{aud['delay']} ms" if not 'ms' in str(aud['delay']) else str(aud['delay'])))

                for label, value in aud_fields:
                    cell = f"  │  {label:<20} : {value}"
                    cell += ' ' * max(0, 75 - len(cell)) + '│'
                    lines.append(cell)
                lines.append('  └' + '─' * 73 + '┘')
                lines.append('')

            # Subtitles
            if finfo['subtitles']:
                lines.append('  ┌' + '─' * 73 + '┐')
                lines.append('  │  SOUS-TITRES' + ' ' * 58 + '│')
                lines.append('  ├' + '─' * 73 + '┤')
                for sub in finfo['subtitles']:
                    sub_str = f"{sub.get('format', '?')} — {sub.get('language', '?').title()}"
                    if sub.get('title'):
                        sub_str += f" ({sub['title']})"
                    if sub.get('forced') and str(sub['forced']).lower() == 'yes':
                        sub_str += " [Forced]"
                    cell = f"  │  {sub_str}"
                    cell += ' ' * max(0, 75 - len(cell)) + '│'
                    lines.append(cell)
                lines.append('  └' + '─' * 73 + '┘')
                lines.append('')

            # Chapters
            if finfo['chapters']:
                lines.append('  ┌' + '─' * 73 + '┐')
                lines.append('  │  CHAPITRES' + ' ' * 60 + '│')
                lines.append('  ├' + '─' * 73 + '┤')
                for ch in finfo['chapters']:
                    cell = f"  │  {ch.get('title', 'Chapter'):<20} : {ch.get('time', '')}"
                    cell += ' ' * max(0, 75 - len(cell)) + '│'
                    lines.append(cell)
                lines.append('  └' + '─' * 73 + '┘')
                lines.append('')

            lines.append('')

        # ── Summary table ──
        if len(files_info) > 1:
            lines.append('═' * 79)
            lines.append('                              RÉCAPITULATIF')
            lines.append('═' * 79)
            lines.append('')

            # Table header
            lines.append('  ┌──────────┬──────────┬──────────────┬──────────────┬───────────────┬───────────────────┐')
            lines.append('  │  Part    │  Taille  │  Durée       │  Débit vidéo │  Débit audio  │  Résolution       │')
            lines.append('  ├──────────┼──────────┼──────────────┼──────────────┼───────────────┼───────────────────┤')

            total_size = 0
            total_dur = 0
            total_vbytes = 0
            total_abytes = 0

            for idx, finfo in enumerate(files_info):
                gen = finfo['general']
                vid = finfo['video']
                size_str = gen.get('file_size_str', 'N/A')
                dur_str = gen.get('duration_str', 'N/A')
                vbr_str = vid.get('bit_rate_str', 'N/A')
                abr_str = finfo['audio'][0].get('bit_rate_str', 'N/A') if finfo['audio'] else 'N/A'
                res_str = f"{vid.get('width', '?')} x {vid.get('height', '?')}"

                row = f"  │  Part {idx+1:<3}│{size_str:^10}│{dur_str:^14}│{vbr_str:^14}│{abr_str:^15}│{res_str:^19}│"
                lines.append(row)

                total_size += gen.get('file_size', 0)
                total_dur += gen.get('duration', 0)

            lines.append('  ├──────────┼──────────┼──────────────┼──────────────┼───────────────┼───────────────────┤')

            total_size_str = MediaAnalyzer._format_size(total_size)
            total_dur_str = MediaAnalyzer._format_duration(total_dur)

            row = f"  │  TOTAL   │{total_size_str:^10}│{total_dur_str:^14}│{'':^14}│{'':^15}│{'':^19}│"
            lines.append(row)
            lines.append('  └──────────┴──────────┴──────────────┴──────────────┴───────────────┴───────────────────┘')
            lines.append('')

            # Common traits
            lines.append('  Points communs :')
            vid0 = files_info[0]['video']
            x264p = vid0.get('x264_params', {})
            if vid0.get('format') and vid0.get('format_profile'):
                lines.append(f"    • Codec            : {vid0.get('writing_library', vid0['format'])} ({vid0['format']} {vid0['format_profile']})")
            if x264p:
                enc_str = f"CRF {x264p.get('crf', '?')}, ref={x264p.get('ref', '?')}, bframes={x264p.get('bframes', '?')}"
                if x264p.get('cabac') == '1':
                    enc_str += ', CABAC'
                lines.append(f"    • Encodage         : {enc_str}")
            if files_info[0]['audio']:
                a = files_info[0]['audio'][0]
                lines.append(f"    • Audio            : {a.get('format', '')} {a.get('channels', '')}ch, {a.get('language', '').title()}")
            if gen.get('frame_rate'):
                lines.append(f"    • Framerate        : {files_info[0]['general'].get('frame_rate', '')} FPS")

            has_chapters = any(f['chapters'] for f in files_info)
            if has_chapters:
                lines.append(f"    • Chapitres        : Oui")

            has_subs = any(f['subtitles'] for f in files_info)
            lines.append(f"    • Sous-titres      : {'Oui' if has_subs else 'Aucun'}")

            # Warnings
            if x264p.get('ref') and int(x264p.get('ref', 0)) < 3:
                lines.append('')
                lines.append(f"  ⚠  Avertissement ref={x264p['ref']} :")
                lines.append(f"    Certains trackers exigent un minimum de ref=3. Ce release utilise")
                lines.append(f"    ref={x264p['ref']} sur les {len(files_info)} parts. Vérifier les règles du tracker avant upload.")

        lines.append('')
        lines.append('═' * 79)
        lines.append(f'  NFO généré par {APP_NAME} v{APP_VERSION} le {datetime.now().strftime("%Y-%m-%d à %H:%M:%S")}')
        lines.append('═' * 79)
        lines.append('')

        return '\n'.join(lines)

    @staticmethod
    def _estimate_preset(params):
        """Estimate x264 preset from encoding parameters."""
        subme = int(params.get('subme', 0))
        me = params.get('me', '')
        ref = int(params.get('ref', 0))
        trellis = int(params.get('trellis', 0))
        bframes = int(params.get('bframes', 0))

        if subme >= 10:
            return 'Placebo'
        elif subme >= 9 and me in ('tesa', 'esa'):
            return 'Veryslow'
        elif subme >= 8 and me == 'umh':
            return 'Slower'
        elif subme >= 7 and me == 'umh':
            return 'Slow'
        elif subme >= 7:
            return 'Medium'
        elif subme >= 6:
            return 'Medium'
        elif subme >= 4:
            return 'Fast'
        elif subme >= 2:
            return 'Faster'
        elif subme >= 1:
            return 'Veryfast'
        return None


# ═══════════════════════════════════════════════════════════════════
#  RELEASE NAME BUILDER
# ═══════════════════════════════════════════════════════════════════

class ReleaseNameBuilder:
    """Build a release name in tracker format:
    Titre.Année.Langue.Résolution.Source.(Détails).CodecAudio.CodecVidéo-TAG
    """

    @staticmethod
    def build(files_info, tmdb_info=None, tag='', language_override='', source_override=''):
        """Build release name from analyzed data."""
        vid = files_info[0].get('video', {})
        aud = files_info[0].get('audio', [{}])
        gen = files_info[0].get('general', {})
        x264p = vid.get('x264_params', {})

        # Title
        title = ''
        if tmdb_info and tmdb_info.get('title'):
            title = tmdb_info['title']
        else:
            # Extract from filename
            title = TMDBFetcher._clean_filename(files_info[0].get('filename', ''))
        title = title.replace(' ', '.')

        # Remove accents from title
        title = ReleaseNameBuilder._remove_accents(title)

        # Year
        year = ''
        if tmdb_info and tmdb_info.get('year'):
            year = tmdb_info['year']
        else:
            # Try to find year in filename
            match = re.search(r'(19|20)\d{2}', files_info[0].get('filename', ''))
            if match:
                year = match.group(0)

        # Language
        lang = language_override
        if not lang:
            languages = set()
            for f in files_info:
                for a in f.get('audio', []):
                    l = (a.get('language') or '').lower()
                    if l:
                        languages.add(l)
            if len(languages) > 1:
                lang = 'Multi'
                # Add VFF/VFQ if French is present
                if 'fr' in languages or 'fre' in languages or 'french' in languages:
                    lang = 'Multi.VFF'
            elif 'fr' in languages or 'fre' in languages or 'french' in languages:
                lang = 'FRENCH'
            elif 'en' in languages or 'eng' in languages or 'english' in languages:
                lang = 'ENGLISH'
            elif languages:
                lang = languages.pop().upper()

        # Resolution
        height = vid.get('height', 0)
        width = vid.get('width', 0)
        if height >= 2100:
            resolution = '2160p'
        elif height >= 1000:
            resolution = '1080p'
        elif height >= 700:
            resolution = '720p'
        elif height >= 560:
            resolution = '576p'
        elif height >= 460:
            resolution = '480p'
        else:
            resolution = f"{height}p" if height else ''

        # Source - detect from filename or metadata
        source = source_override
        if not source:
            fname_lower = files_info[0].get('filename', '').lower()
            app_lower = gen.get('writing_application', '').lower()
            if 'bluray' in fname_lower or 'remux' in fname_lower or 'bdremux' in fname_lower:
                source = 'BluRay'
            elif 'bdrip' in fname_lower or 'brrip' in fname_lower:
                source = 'BDRip'
            elif 'hdlight' in fname_lower:
                source = 'HDLight'
            elif 'web-dl' in fname_lower or 'webdl' in fname_lower or 'web.dl' in fname_lower:
                source = 'WEB-DL'
            elif 'webrip' in fname_lower:
                source = 'WEBRip'
            elif 'dvdrip' in fname_lower:
                source = 'DVDRip'
            elif 'hdtv' in fname_lower:
                source = 'HDTV'
            elif 'tvrip' in fname_lower:
                source = 'TVRip'

        # Video codec
        v_codec = ''
        wlib = (vid.get('writing_library') or '').lower()
        fmt = (vid.get('format') or '').lower()
        if 'x264' in wlib or ('avc' in fmt and 'x265' not in wlib):
            v_codec = 'x264'
        elif 'x265' in wlib or 'hevc' in fmt:
            v_codec = 'x265'
        elif 'xvid' in wlib:
            v_codec = 'XviD'
        elif 'avc' in fmt:
            v_codec = 'H.264'
        elif 'hevc' in fmt:
            v_codec = 'H.265'

        # Audio codec + channels
        a_codec = ''
        a_channels = ''
        if aud:
            first_audio = aud[0] if isinstance(aud, list) else aud
            a_fmt = (first_audio.get('format') or '').upper()
            a_commercial = (first_audio.get('commercial_name') or '').upper()
            channels = first_audio.get('channels', 0)

            if 'AC-3' in a_fmt or 'AC3' in a_fmt or 'DOLBY DIGITAL' in a_commercial:
                a_codec = 'AC3'
            elif 'E-AC-3' in a_fmt or 'EAC3' in a_fmt:
                a_codec = 'EAC3'
            elif 'DTS' in a_fmt:
                if 'HD MA' in a_commercial or 'HD MASTER' in a_commercial:
                    a_codec = 'DTS-HD.MA'
                elif 'X' in a_commercial:
                    a_codec = 'DTS-X'
                else:
                    a_codec = 'DTS'
            elif 'AAC' in a_fmt:
                a_codec = 'AAC'
            elif 'FLAC' in a_fmt:
                a_codec = 'FLAC'
            elif 'TRUEHD' in a_fmt or 'TRUE HD' in a_commercial:
                a_codec = 'TrueHD'
            elif 'OPUS' in a_fmt:
                a_codec = 'OPUS'

            if channels == 2:
                a_channels = '2.0'
            elif channels == 6:
                a_channels = '5.1'
            elif channels == 8:
                a_channels = '7.1'
            elif channels:
                a_channels = str(channels)

        # Build the name: Titre.Année.Langue.Résolution.Source.CodecAudio.Channels.CodecVidéo-TAG
        parts = [title]
        if year:
            parts.append(year)
        if lang:
            parts.append(lang)
        if resolution:
            parts.append(resolution)
        if source:
            parts.append(source)
        if a_codec:
            if a_channels:
                parts.append(f"{a_codec}.{a_channels}")
            else:
                parts.append(a_codec)
        if v_codec:
            parts.append(v_codec)

        name = '.'.join(parts)

        # Clean: remove any remaining special characters
        name = re.sub(r'[\'\",:;!?\(\)\[\]{}]', '', name)
        name = re.sub(r'\.{2,}', '.', name)  # No double dots
        name = name.strip('.')

        if tag:
            name += f"-{tag}"

        return name

    @staticmethod
    def _remove_accents(text):
        """Remove accents/diacritics from text."""
        import unicodedata
        # Normalize to decomposed form, filter out combining characters
        nfkd = unicodedata.normalize('NFKD', text)
        return ''.join(c for c in nfkd if not unicodedata.combining(c))



# ═══════════════════════════════════════════════════════════════════
#  GUI APPLICATION
# ═══════════════════════════════════════════════════════════════════

# ═══════════════════════════════════════════════════════════════════
#  TORRENT FILE CREATOR
# ═══════════════════════════════════════════════════════════════════

class TorrentCreator:
    """Create .torrent files for tracker uploads."""

    def __init__(self, log_callback=None):
        self.log = log_callback or print

    def create(self, paths, announce_url, output_path, piece_size=0, private=True, source=''):
        """
        Create a .torrent file.
        paths: list of file paths or a single directory path
        announce_url: tracker announce URL
        output_path: where to save the .torrent
        piece_size: piece size in bytes (0 = auto)
        private: set private flag (required for private trackers)
        source: source tag (some trackers require this)
        """
        if HAS_TORF:
            return self._create_torf(paths, announce_url, output_path, piece_size, private, source)
        else:
            return self._create_manual(paths, announce_url, output_path, piece_size, private, source)

    def _create_torf(self, paths, announce_url, output_path, piece_size, private, source):
        """Create torrent using torf library."""
        try:
            t = torf.Torrent()
            t.private = private

            if announce_url:
                t.trackers = [[announce_url]]

            if source:
                t.source = source

            if piece_size:
                t.piece_size = piece_size

            # Determine input
            if len(paths) == 1 and os.path.isdir(paths[0]):
                t.path = paths[0]
            elif len(paths) == 1:
                t.path = paths[0]
            else:
                # Multiple files — use the common parent directory
                parent = os.path.dirname(paths[0])
                t.path = parent

            t.created_by = f"{APP_NAME} v{APP_VERSION}"

            self.log(f"  ⏳ Hachage des pièces en cours...")
            t.generate(callback=self._progress_callback, interval=1)

            t.write(output_path, overwrite=True)
            self.log(f"  ✅ Torrent créé : {os.path.basename(output_path)}")
            self.log(f"     Taille des pièces : {t.piece_size / 1024:.0f} KiB")
            self.log(f"     Nombre de pièces : {t.pieces}")
            return True

        except Exception as e:
            self.log(f"  ❌ Erreur torf: {e}")
            return False

    def _progress_callback(self, torrent, filepath, pieces_done, pieces_total):
        """Progress callback for torf."""
        if pieces_total > 0:
            pct = (pieces_done / pieces_total) * 100
            if pieces_done % max(1, pieces_total // 20) == 0 or pieces_done == pieces_total:
                self.log(f"    Hachage : {pct:.0f}% ({pieces_done}/{pieces_total} pièces)")

    def _create_manual(self, paths, announce_url, output_path, piece_size, private, source):
        """Create torrent using system tools (mktorrent, transmission-create, etc.)."""
        # Try mktorrent first
        mktorrent = self._find_tool(['mktorrent'])
        if mktorrent:
            return self._create_mktorrent(mktorrent, paths, announce_url, output_path, piece_size, private, source)

        # Try transmission-create
        transmission = self._find_tool(['transmission-create'])
        if transmission:
            return self._create_transmission(transmission, paths, announce_url, output_path, piece_size, private)

        self.log("  ❌ Aucun outil torrent disponible !")
        self.log("     Installez l'un des suivants :")
        self.log("     • pip install torf (recommandé)")
        self.log("     • sudo apt install mktorrent")
        self.log("     • sudo apt install transmission-cli")
        return False

    def _find_tool(self, names):
        """Find a command-line tool."""
        for name in names:
            try:
                result = subprocess.run([name, '--help'], capture_output=True, timeout=5)
                return name
            except (FileNotFoundError, subprocess.TimeoutExpired):
                continue
        return None

    def _create_mktorrent(self, tool, paths, announce_url, output_path, piece_size, private, source):
        """Create torrent using mktorrent."""
        try:
            input_path = paths[0] if len(paths) == 1 else os.path.dirname(paths[0])

            cmd = [tool]
            if private:
                cmd.append('-p')
            if announce_url:
                cmd.extend(['-a', announce_url])
            if source:
                cmd.extend(['-s', source])
            if piece_size:
                # mktorrent uses log2 of piece size in KiB
                import math
                pl = int(math.log2(piece_size / 1024))
                cmd.extend(['-l', str(pl)])
            cmd.extend(['-o', output_path, input_path])

            self.log(f"  ⏳ Création du torrent avec mktorrent...")
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=600)

            if result.returncode == 0:
                self.log(f"  ✅ Torrent créé : {os.path.basename(output_path)}")
                return True
            else:
                self.log(f"  ❌ Erreur mktorrent: {result.stderr}")
                return False

        except Exception as e:
            self.log(f"  ❌ Erreur mktorrent: {e}")
            return False

    def _create_transmission(self, tool, paths, announce_url, output_path, piece_size, private):
        """Create torrent using transmission-create."""
        try:
            input_path = paths[0] if len(paths) == 1 else os.path.dirname(paths[0])

            cmd = [tool]
            if private:
                cmd.append('-p')
            if announce_url:
                cmd.extend(['-t', announce_url])
            if piece_size:
                cmd.extend(['-s', str(piece_size // 1024)])
            cmd.extend(['-o', output_path, input_path])

            self.log(f"  ⏳ Création du torrent avec transmission-create...")
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=600)

            if result.returncode == 0:
                self.log(f"  ✅ Torrent créé : {os.path.basename(output_path)}")
                return True
            else:
                self.log(f"  ❌ Erreur transmission-create: {result.stderr}")
                return False

        except Exception as e:
            self.log(f"  ❌ Erreur: {e}")
            return False


class NFOGeneratorApp:
    """Main GUI application."""

    def __init__(self, root):
        self.root = root
        self.root.title(f"{APP_NAME} v{APP_VERSION} — NFO Generator")
        self.root.geometry("900x700")
        self.root.minsize(800, 600)

        # Configure style
        self.style = ttk.Style()
        try:
            self.style.theme_use('clam')
        except Exception:
            pass

        self.files = []
        self.tmdb_api_key = self._load_api_key()
        self.analyzer = MediaAnalyzer(log_callback=self._log)
        self.tmdb = TMDBFetcher(api_key=self.tmdb_api_key, log_callback=self._log)
        self.torrent_creator = TorrentCreator(log_callback=self._log)

        self._build_ui()

    def _build_ui(self):
        """Build the main UI."""
        main = ttk.Frame(self.root, padding=10)
        main.pack(fill=tk.BOTH, expand=True)

        # ── Title ──
        title_frame = ttk.Frame(main)
        title_frame.pack(fill=tk.X, pady=(0, 10))
        ttk.Label(title_frame, text=f"🎬 {APP_NAME}", font=('Helvetica', 18, 'bold')).pack(side=tk.LEFT)
        ttk.Label(title_frame, text=f"v{APP_VERSION} — NFO Generator pour trackers privés",
                  font=('Helvetica', 10)).pack(side=tk.LEFT, padx=10, pady=5)

        # ── Drop zone ──
        drop_frame = ttk.LabelFrame(main, text=" Fichiers vidéo ", padding=10)
        drop_frame.pack(fill=tk.X, pady=(0, 10))

        self.drop_label = ttk.Label(
            drop_frame,
            text="📂  Cliquez sur « Ajouter » ou glissez-déposez des fichiers/dossiers ici",
            font=('Helvetica', 11),
            anchor='center',
        )
        self.drop_label.pack(fill=tk.X, pady=15)

        btn_frame = ttk.Frame(drop_frame)
        btn_frame.pack(fill=tk.X)
        ttk.Button(btn_frame, text="➕ Ajouter fichier(s)", command=self._add_files).pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_frame, text="📁 Ajouter dossier", command=self._add_folder).pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_frame, text="🗑 Vider la liste", command=self._clear_files).pack(side=tk.LEFT, padx=5)

        # File list
        self.file_listbox = tk.Listbox(drop_frame, height=5, font=('Courier', 9))
        self.file_listbox.pack(fill=tk.X, pady=(10, 0))

        # ── Options ──
        opt_frame = ttk.LabelFrame(main, text=" Options ", padding=10)
        opt_frame.pack(fill=tk.X, pady=(0, 10))

        # TMDB API key
        tmdb_frame = ttk.Frame(opt_frame)
        tmdb_frame.pack(fill=tk.X, pady=2)
        ttk.Label(tmdb_frame, text="Clé API TMDB :").pack(side=tk.LEFT)
        self.tmdb_entry = ttk.Entry(tmdb_frame, width=40, show='*')
        self.tmdb_entry.pack(side=tk.LEFT, padx=5)
        if self.tmdb_api_key:
            self.tmdb_entry.insert(0, self.tmdb_api_key)
        ttk.Button(tmdb_frame, text="💾", width=3, command=self._save_api_key).pack(side=tk.LEFT)
        ttk.Label(tmdb_frame, text="(gratuit sur themoviedb.org)", font=('Helvetica', 8)).pack(side=tk.LEFT, padx=5)

        # TMDB search override
        search_frame = ttk.Frame(opt_frame)
        search_frame.pack(fill=tk.X, pady=2)
        ttk.Label(search_frame, text="Recherche TMDB :").pack(side=tk.LEFT)
        self.search_entry = ttk.Entry(search_frame, width=40)
        self.search_entry.pack(side=tk.LEFT, padx=5)
        ttk.Label(search_frame, text="(laisser vide = auto-détection)", font=('Helvetica', 8)).pack(side=tk.LEFT, padx=5)

        # Release name
        release_frame = ttk.Frame(opt_frame)
        release_frame.pack(fill=tk.X, pady=2)
        ttk.Label(release_frame, text="Nom du release :").pack(side=tk.LEFT)
        self.release_entry = ttk.Entry(release_frame, width=40)
        self.release_entry.pack(side=tk.LEFT, padx=5)
        ttk.Label(release_frame, text="(laisser vide = auto-généré)", font=('Helvetica', 8)).pack(side=tk.LEFT, padx=5)

        # TAG (release group)
        tag_frame = ttk.Frame(opt_frame)
        tag_frame.pack(fill=tk.X, pady=2)
        ttk.Label(tag_frame, text="TAG (team) :").pack(side=tk.LEFT)
        self.tag_entry = ttk.Entry(tag_frame, width=20)
        self.tag_entry.pack(side=tk.LEFT, padx=5)
        ttk.Label(tag_frame, text="(ex: Sybelius, LOST, FRATERNiTY)", font=('Helvetica', 8)).pack(side=tk.LEFT, padx=5)

        # Checkboxes
        chk_frame = ttk.Frame(opt_frame)
        chk_frame.pack(fill=tk.X, pady=5)
        self.var_tmdb = tk.BooleanVar(value=True)
        self.var_bitrate_calc = tk.BooleanVar(value=True)
        ttk.Checkbutton(chk_frame, text="Rechercher infos TMDB", variable=self.var_tmdb).pack(side=tk.LEFT, padx=10)
        ttk.Checkbutton(chk_frame, text="Calculer bitrates manquants (plus lent)", variable=self.var_bitrate_calc).pack(side=tk.LEFT, padx=10)

        # ── Torrent creation ──
        torrent_frame = ttk.LabelFrame(main, text=" Création .torrent ", padding=10)
        torrent_frame.pack(fill=tk.X, pady=(0, 10))

        self.var_create_torrent = tk.BooleanVar(value=False)
        ttk.Checkbutton(torrent_frame, text="Créer le fichier .torrent",
                        variable=self.var_create_torrent,
                        command=self._toggle_torrent_fields).pack(anchor=tk.W)

        self.torrent_fields_frame = ttk.Frame(torrent_frame)
        self.torrent_fields_frame.pack(fill=tk.X, pady=(5, 0))

        # Announce URL
        ann_frame = ttk.Frame(self.torrent_fields_frame)
        ann_frame.pack(fill=tk.X, pady=2)
        ttk.Label(ann_frame, text="URL d'annonce :").pack(side=tk.LEFT)
        self.announce_entry = ttk.Entry(ann_frame, width=50)
        self.announce_entry.pack(side=tk.LEFT, padx=5)
        ttk.Button(ann_frame, text="💾", width=3, command=self._save_announce_url).pack(side=tk.LEFT)

        # Load saved announce URL
        saved_announce = self._load_config_value('announce_url')
        if saved_announce:
            self.announce_entry.insert(0, saved_announce)

        # Source tag
        src_frame = ttk.Frame(self.torrent_fields_frame)
        src_frame.pack(fill=tk.X, pady=2)
        ttk.Label(src_frame, text="Source tag :").pack(side=tk.LEFT)
        self.source_tag_entry = ttk.Entry(src_frame, width=20)
        self.source_tag_entry.pack(side=tk.LEFT, padx=5)
        ttk.Label(src_frame, text="(ex: C411 — certains trackers l'exigent)", font=('Helvetica', 8)).pack(side=tk.LEFT, padx=5)

        saved_source = self._load_config_value('source_tag')
        if saved_source:
            self.source_tag_entry.insert(0, saved_source)

        # Piece size
        ps_frame = ttk.Frame(self.torrent_fields_frame)
        ps_frame.pack(fill=tk.X, pady=2)
        ttk.Label(ps_frame, text="Taille pièces :").pack(side=tk.LEFT)
        self.piece_size_var = tk.StringVar(value='Auto')
        piece_combo = ttk.Combobox(ps_frame, textvariable=self.piece_size_var, width=15, state='readonly',
                                   values=['Auto', '256 KiB', '512 KiB', '1 MiB', '2 MiB', '4 MiB', '8 MiB', '16 MiB'])
        piece_combo.pack(side=tk.LEFT, padx=5)
        ttk.Label(ps_frame, text="(auto = adapté à la taille des fichiers)", font=('Helvetica', 8)).pack(side=tk.LEFT, padx=5)

        # Torrent options
        topt_frame = ttk.Frame(self.torrent_fields_frame)
        topt_frame.pack(fill=tk.X, pady=2)
        self.var_private = tk.BooleanVar(value=True)
        ttk.Checkbutton(topt_frame, text="Privé (obligatoire pour trackers privés)", variable=self.var_private).pack(side=tk.LEFT, padx=10)

        # Initially hide torrent fields
        self.torrent_fields_frame.pack_forget()

        # ── Generate buttons ──
        gen_frame = ttk.Frame(main)
        gen_frame.pack(fill=tk.X, pady=5)
        self.gen_btn = ttk.Button(gen_frame, text="⚡ GÉNÉRER LE NFO", command=self._generate)
        self.gen_btn.pack(fill=tk.X, ipady=8)

        # ── Log ──
        log_frame = ttk.LabelFrame(main, text=" Journal ", padding=5)
        log_frame.pack(fill=tk.BOTH, expand=True)
        self.log_text = scrolledtext.ScrolledText(log_frame, height=10, font=('Courier', 9), state='disabled')
        self.log_text.pack(fill=tk.BOTH, expand=True)

        # Setup drag and drop (platform-specific)
        self._setup_dnd()

    def _setup_dnd(self):
        """Setup drag and drop support."""
        # Try tkdnd
        try:
            self.root.tk.eval('package require tkdnd')
            self.root.tk.eval(f'tkdnd::drop_target register {self.drop_label.winfo_pathname(self.drop_label.winfo_id())} *')

            def on_drop(event):
                files = self.root.tk.splitlist(event.data)
                for f in files:
                    self._add_path(f)
                return event.action

            self.drop_label.bind('<<Drop>>', on_drop)
            self._log("✓ Drag & drop activé (tkdnd)")
        except Exception:
            self._log("ℹ Drag & drop natif non disponible.")
            self._log("  → Utilisez les boutons Ajouter pour sélectionner les fichiers.")
            self._log("  → Pour activer le drag & drop : pip install tkinterdnd2")

    def _add_files(self):
        """Open file dialog to add video files."""
        exts = ' '.join(f'*{e}' for e in VIDEO_EXTENSIONS)
        files = filedialog.askopenfilenames(
            title="Sélectionner des fichiers vidéo",
            filetypes=[("Fichiers vidéo", exts), ("Tous les fichiers", "*.*")]
        )
        for f in files:
            self._add_path(f)

    def _add_folder(self):
        """Open folder dialog."""
        folder = filedialog.askdirectory(title="Sélectionner un dossier contenant des vidéos")
        if folder:
            self._add_path(folder)

    def _add_path(self, path):
        """Add a file or folder to the list."""
        path = str(path).strip()
        if os.path.isdir(path):
            for entry in sorted(os.listdir(path)):
                full = os.path.join(path, entry)
                if os.path.isfile(full) and Path(full).suffix.lower() in VIDEO_EXTENSIONS:
                    if full not in self.files:
                        self.files.append(full)
                        self.file_listbox.insert(tk.END, os.path.basename(full))
        elif os.path.isfile(path) and Path(path).suffix.lower() in VIDEO_EXTENSIONS:
            if path not in self.files:
                self.files.append(path)
                self.file_listbox.insert(tk.END, os.path.basename(path))

        self.drop_label.config(text=f"📂  {len(self.files)} fichier(s) sélectionné(s)")

    def _clear_files(self):
        """Clear file list."""
        self.files.clear()
        self.file_listbox.delete(0, tk.END)
        self.drop_label.config(text="📂  Cliquez sur « Ajouter » ou glissez-déposez des fichiers/dossiers ici")

    def _log(self, message):
        """Add a message to the log."""
        self.log_text.config(state='normal')
        self.log_text.insert(tk.END, message + '\n')
        self.log_text.see(tk.END)
        self.log_text.config(state='disabled')
        self.root.update_idletasks()

    def _generate(self):
        """Generate NFO in a separate thread."""
        if not self.files:
            messagebox.showwarning("Aucun fichier", "Ajoutez au moins un fichier vidéo.")
            return

        self.gen_btn.config(state='disabled')
        self.tmdb.api_key = self.tmdb_entry.get().strip()

        thread = threading.Thread(target=self._generate_worker, daemon=True)
        thread.start()

    def _generate_worker(self):
        """Worker thread for NFO generation."""
        try:
            self._log("\n" + "=" * 60)
            self._log(f"Démarrage de l'analyse — {len(self.files)} fichier(s)")
            self._log("=" * 60)

            # Analyze all files
            files_info = []
            for filepath in self.files:
                info = self.analyzer.analyze_file(filepath)
                files_info.append(info)

            # TMDB search
            tmdb_info = None
            if self.var_tmdb.get():
                search_query = self.search_entry.get().strip()
                if not search_query and self.files:
                    search_query = os.path.basename(self.files[0])
                if search_query and self.tmdb.api_key:
                    tmdb_info = self.tmdb.search(search_query)

            # Tag
            tag = self.tag_entry.get().strip()

            # Auto-detect tag from filename if not provided
            if not tag:
                fname = files_info[0].get('filename', '')
                m = re.search(r'-([a-zA-Z0-9]+)\.[a-zA-Z0-9]{2,4}$', fname)
                if m:
                    tag = m.group(1)

            # Release name
            release_name = self.release_entry.get().strip()
            if not release_name:
                release_name = ReleaseNameBuilder.build(
                    files_info, tmdb_info, tag=tag
                )
                self._log(f"\n📋 Release name auto-généré :")
                self._log(f"   {release_name}")

            # Generate NFO
            self._log("\n📝 Génération du NFO...")
            nfo_content = NFOFormatter.generate(files_info, tmdb_info, release_name)

            # Log the title to copy
            self._log("\n" + "=" * 60)
            self._log("📋 TITRE À COPIER-COLLER SUR LE TRACKER :")
            self._log(f"   {release_name}")
            self._log("=" * 60)

            # Save
            default_dir = os.path.dirname(self.files[0])
            safe_name = re.sub(r'[^\w\-\.]', '_', release_name or 'output')

            self.root.after(0, lambda: self._save_all(
                nfo_content, release_name,
                default_dir, safe_name
            ))

        except Exception as e:
            self._log(f"\n❌ Erreur : {e}")
            import traceback
            self._log(traceback.format_exc())
        finally:
            self.root.after(0, lambda: self.gen_btn.config(state='normal'))

    def _save_all(self, nfo_content, release_name,
                  default_dir, default_name):
        """Save NFO, create torrent, and show release name."""
        folder = filedialog.askdirectory(
            title="Dossier de destination pour les fichiers générés",
            initialdir=default_dir,
        )
        if not folder:
            self._log("\n⚠ Sauvegarde annulée.")
            return

        # Save NFO
        nfo_path = os.path.join(folder, f"{default_name}.nfo")
        with open(nfo_path, 'w', encoding='utf-8') as f:
            f.write(nfo_content)
        self._log(f"\n✅ NFO enregistré : {nfo_path}")

        # Create torrent if requested
        torrent_path = None
        if self.var_create_torrent.get():
            announce_url = self.announce_entry.get().strip()
            if not announce_url:
                self._log("\n⚠ URL d'annonce vide — torrent non créé")
                messagebox.showwarning("URL manquante",
                    "Renseignez l'URL d'annonce du tracker pour créer le .torrent")
            else:
                torrent_path = os.path.join(folder, f"{default_name}.torrent")
                source_tag = self.source_tag_entry.get().strip()
                piece_size = self._parse_piece_size()

                self._log(f"\n🔧 Création du fichier .torrent...")
                self._log(f"   Announce : {announce_url}")
                if source_tag:
                    self._log(f"   Source   : {source_tag}")

                # Create torrent in a thread to not block
                def create_torrent():
                    success = self.torrent_creator.create(
                        paths=self.files,
                        announce_url=announce_url,
                        output_path=torrent_path,
                        piece_size=piece_size,
                        private=self.var_private.get(),
                        source=source_tag,
                    )
                    if success:
                        self.root.after(0, lambda: self._show_result_popup(
                            release_name, nfo_path, torrent_path))
                    else:
                        self.root.after(0, lambda: self._show_result_popup(
                            release_name, nfo_path, None))

                thread = threading.Thread(target=create_torrent, daemon=True)
                thread.start()
                return  # Popup will be shown after torrent creation

        # Show result popup immediately (no torrent)
        self._show_result_popup(release_name, nfo_path, torrent_path)

    def _show_result_popup(self, release_name, nfo_path, torrent_path):
        """Show the result popup with release name to copy."""
        self._log(f"\n{'='*60}")
        self._log(f"📋 TITRE À COPIER-COLLER :")
        self._log(f"   {release_name}")
        self._log(f"{'='*60}")

        popup = tk.Toplevel(self.root)
        popup.title("Génération terminée !")
        popup.geometry("700x300")
        popup.transient(self.root)

        ttk.Label(popup, text="✅ Fichiers générés avec succès !",
                  font=('Helvetica', 14, 'bold')).pack(pady=10)

        # Release name to copy
        ttk.Label(popup, text="📋 Titre à copier-coller sur le tracker :",
                  font=('Helvetica', 11)).pack(pady=(10, 2))
        name_frame = ttk.Frame(popup)
        name_frame.pack(fill=tk.X, padx=20, pady=5)
        name_entry = ttk.Entry(name_frame, font=('Courier', 11))
        name_entry.pack(side=tk.LEFT, fill=tk.X, expand=True)
        name_entry.insert(0, release_name)
        name_entry.select_range(0, tk.END)

        def copy_name():
            popup.clipboard_clear()
            popup.clipboard_append(release_name)
            copy_btn.config(text="✓ Copié !")
        copy_btn = ttk.Button(name_frame, text="📋 Copier", command=copy_name)
        copy_btn.pack(side=tk.RIGHT, padx=5)

        # Files info
        ttk.Label(popup, text=f"NFO : {os.path.basename(nfo_path)}",
                  font=('Helvetica', 9)).pack(pady=2)
        if torrent_path and os.path.exists(torrent_path):
            size = os.path.getsize(torrent_path)
            ttk.Label(popup, text=f"Torrent : {os.path.basename(torrent_path)} ({size/1024:.1f} KiB)",
                      font=('Helvetica', 9)).pack(pady=2)

        ttk.Button(popup, text="Fermer", command=popup.destroy).pack(pady=15)

    def _load_api_key(self):
        """Load TMDB API key from config file."""
        config_path = self._config_path()
        if os.path.exists(config_path):
            try:
                with open(config_path, 'r') as f:
                    data = json.load(f)
                    return data.get('tmdb_api_key', '')
            except Exception:
                pass
        return ''

    def _save_api_key(self):
        """Save TMDB API key to config file."""
        config_path = self._config_path()
        os.makedirs(os.path.dirname(config_path), exist_ok=True)
        data = {}
        if os.path.exists(config_path):
            try:
                with open(config_path, 'r') as f:
                    data = json.load(f)
            except Exception:
                pass
        data['tmdb_api_key'] = self.tmdb_entry.get().strip()
        with open(config_path, 'w') as f:
            json.dump(data, f, indent=2)
        self._log("💾 Clé API TMDB sauvegardée.")

    def _save_announce_url(self):
        """Save announce URL and source tag to config."""
        self._save_config_value('announce_url', self.announce_entry.get().strip())
        self._save_config_value('source_tag', self.source_tag_entry.get().strip())
        self._log("💾 URL d'annonce et source tag sauvegardés.")

    def _save_config_value(self, key, value):
        """Save a single config value."""
        config_path = self._config_path()
        os.makedirs(os.path.dirname(config_path), exist_ok=True)
        data = {}
        if os.path.exists(config_path):
            try:
                with open(config_path, 'r') as f:
                    data = json.load(f)
            except Exception:
                pass
        data[key] = value
        with open(config_path, 'w') as f:
            json.dump(data, f, indent=2)

    def _load_config_value(self, key, default=''):
        """Load a single config value."""
        config_path = self._config_path()
        if os.path.exists(config_path):
            try:
                with open(config_path, 'r') as f:
                    data = json.load(f)
                    return data.get(key, default)
            except Exception:
                pass
        return default

    def _toggle_torrent_fields(self):
        """Show/hide torrent creation fields."""
        if self.var_create_torrent.get():
            self.torrent_fields_frame.pack(fill=tk.X, pady=(5, 0))
        else:
            self.torrent_fields_frame.pack_forget()

    def _parse_piece_size(self):
        """Parse piece size from combobox value."""
        val = self.piece_size_var.get()
        if val == 'Auto':
            return 0
        mapping = {
            '256 KiB': 256 * 1024,
            '512 KiB': 512 * 1024,
            '1 MiB': 1024 * 1024,
            '2 MiB': 2 * 1024 * 1024,
            '4 MiB': 4 * 1024 * 1024,
            '8 MiB': 8 * 1024 * 1024,
            '16 MiB': 16 * 1024 * 1024,
        }
        return mapping.get(val, 0)

    @staticmethod
    def _config_path():
        """Get config file path."""
        if sys.platform == 'win32':
            base = os.environ.get('APPDATA', os.path.expanduser('~'))
        elif sys.platform == 'darwin':
            base = os.path.expanduser('~/Library/Application Support')
        else:
            base = os.environ.get('XDG_CONFIG_HOME', os.path.expanduser('~/.config'))
        return os.path.join(base, 'ch1nf0', 'config.json')


# ═══════════════════════════════════════════════════════════════════
#  MAIN ENTRY POINT
# ═══════════════════════════════════════════════════════════════════

def main():
    root = tk.Tk()

    # Set icon if available
    try:
        if sys.platform == 'win32':
            root.iconbitmap(default='')
    except Exception:
        pass

    app = NFOGeneratorApp(root)

    # Handle CLI arguments (drag & drop onto exe)
    for arg in sys.argv[1:]:
        if os.path.exists(arg):
            app._add_path(arg)

    root.mainloop()


if __name__ == '__main__':
    main()
