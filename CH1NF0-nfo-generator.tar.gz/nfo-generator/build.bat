@echo off
REM ═══════════════════════════════════════════════════════
REM  CH1NF0 — Build script Windows
REM ═══════════════════════════════════════════════════════

echo ╔══════════════════════════════════════╗
echo ║  CH1NF0 Builder - Windows            ║
echo ╚══════════════════════════════════════╝
echo.

echo 📦 Installation des dependances...
pip install -r requirements.txt

echo.
echo 🔨 Compilation de l'executable...

pyinstaller ^
    --onefile ^
    --windowed ^
    --name "CH1NF0" ^
    --clean ^
    nfo_generator.py

echo.
echo ✅ Build termine !
echo    Executable : dist\CH1NF0.exe
echo.
echo 📋 Prerequis sur la machine cible :
echo    * mediainfo (telecharger sur https://mediaarea.net/fr/MediaInfo)
echo    * ffmpeg    (telecharger sur https://ffmpeg.org/download.html)
echo.
pause
